<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://www.prositeweb.ca/
 * @since      1.0.0
 *
 * @package    Prositecaptcha
 * @subpackage Prositecaptcha/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Prositecaptcha
 * @subpackage Prositecaptcha/public
 * @author     Prositeweb Inc <contact@prositeweb.ca>
 */
class Prositecaptcha_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;
	private $public_key, $private_key;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {
        $options = get_option($this->plugin_name);
		$this->plugin_name = $plugin_name;
		$this->version = $version;
			$this->public_key  = $options['api_sid'];
		$this->private_key = $options['api_auth_token'];

		// adds the captcha to the login form
	///	add_action( 'login_form', array( $this, 'captcha_display' ) );
	//	 add_action( 'register_form', array( $this, 'captcha_display' ));

		// authenticate the captcha answer
	//	add_action( 'wp_authenticate_user', array( $this, 'validate_captcha_field' ), 10, 2 );

	}
    public function captcha_display() {
        $options = get_option($this->plugin_name);
        $this->public_key  = $options['api_sid'];
		$this->private_key = $options['api_auth_token'];
		if(!empty($this->public_key) && !empty($this->private_key)) {
		?>
	<input type="hidden" name="recaptcha_response" id="recaptchaResponse">

	<?php
		}
	}

	public function validate_captcha_field($user, $password) {
$options = get_option($this->plugin_name);
        $this->public_key  = $options['api_sid'];
		$this->private_key = $options['api_auth_token'];
		if(!empty($this->public_key) && !empty($this->private_key)) {
		    $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
    $recaptcha_secret = $this->private_key;
    $recaptcha_response = $_POST['recaptcha_response'];
		$recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
    $recaptcha = json_decode($recaptcha);    
		   if ($recaptcha->score < 0.5) {
		       return new WP_Error( 'invalid_captcha', 'CAPTCHA response was incorrect'); 
		   }
		
	}
		return $user;
	}
	
		public function validate_captcha_registration_field($errors, $sanitized_user_login, $user_email) {
$options = get_option($this->plugin_name);
        $this->public_key  = $options['api_sid'];
		$this->private_key = $options['api_auth_token'];
		if(!empty($this->public_key) && !empty($this->private_key)) {
		    $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
    $recaptcha_secret = $this->private_key;
    $recaptcha_response = $_POST['recaptcha_response'];
		$recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
    $recaptcha = json_decode($recaptcha);    
		   if ($recaptcha->score <  0.5) {
		       return new WP_Error( 'invalid_captcha', 'CAPTCHA response was incorrect'); 
		   }
		
	}
		return $errors;
	}
	
	function captcha_script() {
	    $options = get_option($this->plugin_name);
    ?>
    <script src="https://www.google.com/recaptcha/api.js?render=<?php echo $options['api_sid']; ?>"></script>
    <script>
        grecaptcha.ready(function () {
            grecaptcha.execute('<?php echo $options['api_sid']; ?>', { action: 'contact' }).then(function (token) {
                var recaptchaResponse = document.getElementById('recaptchaResponse');
                recaptchaResponse.value = token;
            });
        });
    </script>
    <?php 
}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Prositecaptcha_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Prositecaptcha_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/prositecaptcha-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Prositecaptcha_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Prositecaptcha_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/prositecaptcha-public.js', array( 'jquery' ), $this->version, false );

	}

}


